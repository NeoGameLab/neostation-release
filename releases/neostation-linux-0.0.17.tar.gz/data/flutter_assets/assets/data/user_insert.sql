-- ===========================================
-- USER TABLES - INSERT STATEMENTS
-- ===========================================

-- Insert default ScreenScraper configuration
INSERT OR IGNORE INTO user_screenscraper_config (id, scrape_mode) VALUES (1, 'new_only');


-- ===========================================
-- SYSTEM CONFIGURATIONS
-- ===========================================

-- Insert default system configurations (all enabled by default)
INSERT OR IGNORE INTO user_screenscraper_system_config (app_system_id, enabled) VALUES
(1, 1), -- NES
(2, 1), -- SNES
(3, 1), -- Game Boy
(4, 1), -- Game Boy Color
(5, 1), -- Game Boy Advance
(6, 1), -- Nintendo 64
(7, 1), -- Nintendo DS
(8, 1), -- GameCube
(12, 1), -- Genesis/Mega Drive
(13, 1), -- Master System
(14, 1), -- Game Gear
(20, 1), -- PlayStation
(21, 1), -- PlayStation 2
(22, 1), -- PlayStation Portable
(23, 1), -- Atari 2600
(40, 1), -- Arcade
(41, 1); -- 3DO